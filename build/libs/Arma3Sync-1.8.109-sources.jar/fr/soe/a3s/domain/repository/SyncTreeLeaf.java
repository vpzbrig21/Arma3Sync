package fr.soe.a3s.domain.repository;

import java.io.Serializable;

public class SyncTreeLeaf extends SyncTreeNodeMethods implements SyncTreeNode,
		Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8849248143660225239L;
	private String name;
	private SyncTreeDirectory parent;
	private String sha1;// remote sha1
	private long size;
	private long compressedSize;
	private transient long complete;// file completion in %
	private transient String destinationPath;
	private transient String localSHA1;// local sha1
	private boolean updated = false;
	private boolean deleted = false;
	private boolean compressed = false;
	private transient boolean optional = false;

	public SyncTreeLeaf(String name, SyncTreeDirectory parent) {
		super();
		this.name = name;
		this.parent = parent;
	}

	@Override
	public String getName() {
		return this.name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public SyncTreeDirectory getParent() {
		return this.parent;
	}

	@Override
	public void setParent(SyncTreeDirectory parent) {
		this.parent = parent;
	}

	@Override
	public boolean isLeaf() {
		return true;
	}

	public String getSha1() {
		return sha1;
	}

	public void setSha1(String sha1) {
		this.sha1 = sha1;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public String getDestinationPath() {
		return destinationPath;
	}

	public void setDestinationPath(String destinationPath) {
		this.destinationPath = destinationPath;
	}

	public void setLocalSHA1(String sha1) {
		this.localSHA1 = sha1;
	}

	public String getLocalSHA1() {
		return localSHA1;
	}

	public long getComplete() {
		return complete;
	}

	public void setComplete(long complete) {
		this.complete = complete;
	}

	@Override
	public int compareTo(SyncTreeNode other) {
		String otherName = other != null && other.getName() != null ? other.getName() : "";
		String thisName = this.name != null ? this.name : "";
		return thisName.compareToIgnoreCase(otherName);
	}

	@Override
	public void setDeleted(boolean value) {
		this.deleted = value;
	}

	@Override
	public boolean isDeleted() {
		return this.deleted;
	}

	@Override
	public void setUpdated(boolean value) {
		this.updated = value;
	}

	@Override
	public boolean isUpdated() {
		return this.updated;
	}

	public boolean isCompressed() {
		return this.compressed;
	}

	public void setCompressed(boolean compressed) {
		this.compressed = compressed;
	}

	public long getCompressedSize() {
		return compressedSize;
	}

	public void setCompressedSize(long compressedSize) {
		this.compressedSize = compressedSize;
	}

	@Override
	public String getRelativePath() {
		return determinePath(this);
	}

	@Override
	public void setOptional(boolean value) {
		this.optional = value;
	}

	@Override
	public boolean isOptional() {
		return this.optional;
	}
}
