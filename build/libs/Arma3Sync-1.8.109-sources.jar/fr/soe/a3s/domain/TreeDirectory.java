package fr.soe.a3s.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import fr.soe.a3s.constant.ModsetType;

public class TreeDirectory implements TreeNode, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3917102856123611985L;
	private String name;
	private boolean selected = false;
	private TreeDirectory parent;
	private final List<TreeNode> list = new ArrayList<TreeNode>();
	private boolean marked = false;
	private boolean optional = false;
	private transient boolean updated = false;
	private ModsetType modsetType;
	private String modsetRepositoryName;

	public TreeDirectory(String name, TreeDirectory parent) {
		this.name = name;
		this.parent = parent;
	}

	public void addTreeNode(TreeNode treeNode) {

		list.add(treeNode);

		List<TreeDirectory> directories = new ArrayList<TreeDirectory>();
		List<TreeLeaf> leafs = new ArrayList<TreeLeaf>();
		for (TreeNode t : list) {
			if (t instanceof TreeDirectory) {
				directories.add((TreeDirectory) t);
			} else {
				leafs.add((TreeLeaf) t);
			}
		}
		Collections.sort(directories);
		Collections.sort(leafs);
		list.clear();
		list.addAll(directories);
		list.addAll(leafs);
	}

	@Override
	public boolean isLeaf() {
		return false;
	}

	@Override
	public boolean isSelected() {
		return selected;
	}

	@Override
	public void setSelected(boolean value) {
		this.selected = value;
	}

	public List<TreeNode> getList() {
		return list;
	}

	@Override
	public String toString() {
		return name;
	}

	@Override
	public int compareTo(TreeNode other) {
		String otherName = other != null && other.getName() != null ? other.getName() : "";
		String thisName = this.name != null ? this.name : "";
		return thisName.compareToIgnoreCase(otherName);
	}

	@Override
	public void setParent(TreeDirectory parent) {
		this.parent = parent;
	}

	@Override
	public TreeDirectory getParent() {
		return this.parent;
	}

	public void setMarked(boolean value) {
		this.marked = value;
	}

	public boolean isMarked() {
		return marked;
	}

	public void removeTreeNode(TreeNode treeNode) {
		list.remove(treeNode);
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setOptional(boolean value) {
		this.optional = value;
	}

	@Override
	public boolean isOptional() {
		return this.optional;
	}

	public boolean isUpdated() {
		return updated;
	}

	public void setUpdated(boolean updated) {
		this.updated = updated;
	}

	public ModsetType getModsetType() {
		return modsetType;
	}

	public void setModsetType(ModsetType modsetType) {
		this.modsetType = modsetType;
	}

	public String getModsetRepositoryName() {
		return modsetRepositoryName;
	}

	public void setModsetRepositoryName(String modsetRepositoryName) {
		this.modsetRepositoryName = modsetRepositoryName;
	}
}
