package fr.soe.a3s.domain;

import java.io.Serializable;
import java.util.Objects;

import fr.soe.a3s.constant.CheckRepositoriesFrequency;
import fr.soe.a3s.constant.IconResize;
import fr.soe.a3s.constant.LookAndFeel;
import fr.soe.a3s.constant.MinimizationType;
import fr.soe.a3s.constant.StartWithOS;

public class Preferences implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7034433806261372240L;
	private MinimizationType launchPanelGameLaunch = MinimizationType.TASK_BAR;
	private MinimizationType launchPanelMinimized = MinimizationType.TASK_BAR;
	private LookAndFeel lookAndFeel = LookAndFeel.LAF_DEFAULT;
	private IconResize iconResizeSize = IconResize.NONE;
	private StartWithOS startWithOS = StartWithOS.DISABLED;
	private CheckRepositoriesFrequency checkRepositoriesFrequency = CheckRepositoriesFrequency.FREQ3;

	public MinimizationType getLaunchPanelGameLaunch() {
		return launchPanelGameLaunch;
	}

	public void setLaunchPanelGameLaunch(MinimizationType launchPanelGameLaunch) {
		this.launchPanelGameLaunch = launchPanelGameLaunch;
	}

	public MinimizationType getLaunchPanelMinimized() {
		return launchPanelMinimized;
	}

	public void setLaunchPanelMinimized(MinimizationType launchPanelMinimized) {
		this.launchPanelMinimized = launchPanelMinimized;
	}

	public LookAndFeel getLookAndFeel() {
		lookAndFeel = Objects.requireNonNullElse(lookAndFeel, LookAndFeel.LAF_DEFAULT);
		return lookAndFeel;
	}

	public void setLookAndFeel(LookAndFeel lookAndFeel) {
		this.lookAndFeel = lookAndFeel;
	}

	public IconResize getIconResizeSize() {
		iconResizeSize = Objects.requireNonNullElse(iconResizeSize, IconResize.AUTO);
		return iconResizeSize;
	}

	public void setIconResizeSize(IconResize iconResizeSize) {
		this.iconResizeSize = iconResizeSize;
	}

	public StartWithOS getStartWithOS() {
		startWithOS = Objects.requireNonNullElse(startWithOS, StartWithOS.DISABLED);
		return startWithOS;
	}

	public void setStartWithOS(StartWithOS startWithOS) {
		this.startWithOS = startWithOS;
	}

	public CheckRepositoriesFrequency getCheckRepositoriesFrequency() {
		checkRepositoriesFrequency = Objects.requireNonNullElse(checkRepositoriesFrequency,
				CheckRepositoriesFrequency.FREQ3);
		return checkRepositoriesFrequency;
	}

	public void setCheckRepositoriesFrequency(CheckRepositoriesFrequency checkRepositoriesFrequency) {
		this.checkRepositoriesFrequency = checkRepositoriesFrequency;
	}
}
